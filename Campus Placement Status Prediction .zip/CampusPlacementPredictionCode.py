#!/usr/bin/env python
# coding: utf-8

# ### Task : To build classifiers using different classifications algorithms to predict the Placement Status
# 
# ### Dataset : Job Placement Dataset
# #### Link: https://www.kaggle.com/datasets/ahsan81/job-placement-dataset?select=Job_Placement_Data.csv
#  
# ### Features:
# #### This file contains different attributes of the candidates, educational history and work experience.
# 
# ### Target : status - shows placement status of a student

# In[64]:


import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
from matplotlib import gridspec
import seaborn as sns
import plotly.express as px

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn. neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn import ensemble,svm
from sklearn.ensemble import RandomForestClassifier


from sklearn.metrics import classification_report,confusion_matrix
from sklearn.metrics import accuracy_score,precision_score, recall_score,f1_score,fbeta_score


# # Data Preparation

# In[65]:


#ignore warnings
import warnings
warnings.filterwarnings("ignore")


# In[66]:


data = pd.read_csv("OneDrive\Desktop\Job_Placement_Data.csv")


# In[67]:


data


# In[68]:


data.info()


# # Exploratory Data  Analysis

# In[69]:


data.hist(bins=25, figsize=(15,15))
plt.show()


# In[70]:


features = data[["gender","ssc_percentage","ssc_board","hsc_percentage","hsc_board","hsc_subject","degree_percentage",
                 "undergrad_degree","work_experience","emp_test_percentage","specialisation","mba_percent","status"]].columns
plt.figure(figsize=(15,8*4))
gs = gridspec.GridSpec(8, 2)
for i, c in enumerate(data[features]):
    ax = plt.subplot(gs[i])
    sns.countplot(data = data, x = c,palette="Set3")
plt.show()


# # Data Cleaning

# In[71]:


data.isna().any()


# ## converting Categorical variable with Numerical values.

# In[72]:


data.gender = data.gender.replace({"M": 1, "F" : 0})
data.ssc_board = data.ssc_board.replace({"Others":1,"Central":0})
data.hsc_board = data.hsc_board.replace({"Others":1,"Central":0})
data.hsc_subject = data.hsc_subject.replace({"Commerce":2,"Science":1,"Arts":0})
data.undergrad_degree = data.undergrad_degree.replace({"Sci&Tech":2,"Comm&Mgmt":1,"Others":0})
data.work_experience = data.work_experience.replace({"Yes":1,"No":0})
data.specialisation = data.specialisation.replace({"Mkt&HR":1,"Mkt&Fin":0})
data.status = data.status.replace({"Placed":1,"Not Placed":0})


# In[73]:


data.head()


# # Data Visualization

# In[74]:


feature = ['gender','undergrad_degree','work_experience','specialisation']
fig, ax = plt.subplots(2,2, figsize = (10,10))
axs=ax.ravel()
for i, feature in enumerate(feature):
    sns.countplot(x = feature, hue = 'status',ax=axs[i], data=data,palette="terrain")


# # Visualization
# 
# ##### Males are getting placed more compared to females.
# ##### Students having a degree of Comm&Mgt have a high count of getting placed.
# ##### Students having no work experience are more likely to be placed but overall students with work experience are also placed.
# ##### Males in Marketing and Finance are getting placed more compared to Males in Marketing and HR. However Females in Marketing and HR are getting placed more compared to Marketing and Finance

# In[76]:


plt.pie(x = data.groupby(['status']).status.count(),
        labels = ["Not Placed", "Placed"], autopct='%1.2f%%',
        colors=['#ff9999','#66b3ff'])


# In[77]:


plt.figure(figsize=(12, 7))
plt.title("Relation Between Gender vs mba_percent")

sns.boxplot(x='gender',y='mba_percent',data=data,palette='winter')


# In[78]:


plt.figure(figsize=(12, 7))
plt.title("Relation Between Status vs mba_percent ")

sns.boxplot(x='status',y='mba_percent',data=data,palette='winter')


# # Splitting the Data into Training and Testing Data

# In[79]:


X=data.drop(['status'], axis=1)
Y=data['status']


# In[80]:


X


# In[81]:


X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=42)
print("Number transactions X_train dataset: ", X_train.shape)
print("Number transactions Y_train dataset: ", Y_train.shape)
print("Number transactions X_test dataset: ", X_test.shape)
print("Number transactions Y_test dataset: ", Y_test.shape)


# # Training Models

# ### 1. Decision Tree Classifier

# In[82]:


from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, fbeta_score, roc_curve, auc
import matplotlib.pyplot as plt

# Create the Decision Tree Classifier
dtc = DecisionTreeClassifier(random_state=0)

# Fit the model
dtc.fit(X_train, Y_train)

# Make predictions
pred_dtc = dtc.predict(X_test)

# Calculate and print the metrics
dtc_accuracy = round(accuracy_score(Y_test, pred_dtc), 4) * 100
precision = round(precision_score(Y_test, pred_dtc), 2)
recall = round(recall_score(Y_test, pred_dtc), 2)
f1 = round(f1_score(Y_test, pred_dtc), 2)
f2 = round(fbeta_score(Y_test, pred_dtc, beta=2.0), 2)

print('Decision Tree Classifier- ')
print('accuracy  : ', dtc_accuracy)
print('Precision : ',precision)
print('Recall    : ', recall)
print('F1 Score  : ',f1)
print('F2 Score  : ',f2)

# Plot the ROC curve
fpr, tpr, thresholds = roc_curve(Y_test, pred_dtc)
roc_auc = auc(fpr, tpr)

plt.plot(fpr, tpr, lw=2, alpha=0.3, label='ROC (AUC = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], 'r--')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.title('Receiver Operating Characteristic')
plt.legend(loc='lower right')
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.show()


# ### 2. Simple Linear Regression 

# In[84]:


regressor = LinearRegression()
regressor.fit(X_train, Y_train)
y_pred = regressor.predict(X_test)
print(y_pred)


# In[100]:


# extract the independent variable (degree_percentage) and the dependent variable (status)
X = data['degree_percentage'].values.reshape(-1,1)
Y = data['status'].values.reshape(-1,1)

# create a linear regression object
model = LinearRegression()

# fit the model to the data
model.fit(X, Y)

# make a prediction for a new value of X (degree_percentage)
new_X = np.array([[27.94]])
y_pred = model.predict(new_X)
status_pred = round(y_pred[0][0])
# print the predicted status for someone with 67.94 degree percentage
print(status_pred)


# In[95]:


lin_reg = LinearRegression()
lin_reg.fit(X_train,Y_train)
Y_predict = lin_reg.predict(X_test)
score = lin_reg.score(X_test, Y_test)
linaccuracy = round(score*100,2)
print('accuracy_score percent :', linaccuracy)
msr = np.mean((Y_predict-Y_test)**2)
print("Mean Squared error on Test set : ",msr)


# ### 3. Polynomial Regression 

# In[105]:


from sklearn.preprocessing import PolynomialFeatures
# extract the independent variable (degree_percentage) and the dependent variable (status)
X = data['work_experience'].values.reshape(-1,1)
Y = data['status'].values.reshape(-1,1)

# create a polynomial features object to transform X into polynomial features
poly_features = PolynomialFeatures(degree=2, include_bias=False)
X_poly = poly_features.fit_transform(X)

# create a linear regression object
poly_reg = LinearRegression()

# fit the model to the data
poly_reg.fit(X_poly, Y)

# make a prediction for a new value of X (work experience)
new_X = np.array([[10]])
new_X_poly = poly_features.transform(new_X)
status_pred = round(poly_reg.predict(new_X_poly)[0][0])

# print the predicted status for someone with 67.94 degree percentage
print(status_pred)


# # Model Selection and Performance

# In[106]:


m =ensemble.AdaBoostClassifier(n_estimators= 80)
pred =m.fit(X_train, Y_train).predict(X_test)
imp = m.feature_importances_

for i,v in enumerate(imp):
    print("Feature ",i," Score: ",v)
plt.bar([x for x in range(len(imp))],imp)
plt.show()


# In[107]:


m =ensemble.GradientBoostingClassifier(n_estimators=70, random_state = 123)
pred =m.fit(X_train, Y_train).predict(X_test)
imp = m.feature_importances_

for i,v in enumerate(imp):
    print("Feature ",i," Score: ",v)
plt.bar([x for x in range(len(imp))],imp)
plt.show()


# # Final Report

# ##### During the exploratory data analysis (EDA), it was observed that a higher number of male students were placed in comparison to female students. Additionally, students who had pursued a degree in commerce and management had a higher likelihood of being placed. Work experience was found to be a contributing factor towards placement, although students without work experience were also placed. Marketing and human resources (HR) students had a higher likelihood of being placed compared to students studying marketing and finance.Despite female students performing well in their MBA courses, the salaries offered to male students were higher, and a greater number of male students were placed in comparison to female students. Based on the 12 features analyzed, it can be inferred that a student's academic performance from their 10th grade to MBA plays a significant role in their placement. Additionally, work experience can enhance a student's chances of being placed.

# In[ ]:




