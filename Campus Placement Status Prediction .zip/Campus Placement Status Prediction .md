### Task : To build classifiers using different classifications algorithms to predict the Placement Status

### Dataset : Job Placement Dataset
#### Link: https://www.kaggle.com/datasets/ahsan81/job-placement-dataset?select=Job_Placement_Data.csv
 
### Features:
#### This file contains different attributes of the candidates, educational history and work experience.

### Target : status - shows placement status of a student


```python
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
from matplotlib import gridspec
import seaborn as sns
import plotly.express as px

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn. neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn import ensemble,svm
from sklearn.ensemble import RandomForestClassifier


from sklearn.metrics import classification_report,confusion_matrix
from sklearn.metrics import accuracy_score,precision_score, recall_score,f1_score,fbeta_score

```

# Data Preparation


```python
#ignore warnings
import warnings
warnings.filterwarnings("ignore")
```


```python
data = pd.read_csv("OneDrive\Desktop\Job_Placement_Data.csv")

```


```python
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gender</th>
      <th>ssc_percentage</th>
      <th>ssc_board</th>
      <th>hsc_percentage</th>
      <th>hsc_board</th>
      <th>hsc_subject</th>
      <th>degree_percentage</th>
      <th>undergrad_degree</th>
      <th>work_experience</th>
      <th>emp_test_percentage</th>
      <th>specialisation</th>
      <th>mba_percent</th>
      <th>status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>M</td>
      <td>67.00</td>
      <td>Others</td>
      <td>91.00</td>
      <td>Others</td>
      <td>Commerce</td>
      <td>58.00</td>
      <td>Sci&amp;Tech</td>
      <td>No</td>
      <td>55.0</td>
      <td>Mkt&amp;HR</td>
      <td>58.80</td>
      <td>Placed</td>
    </tr>
    <tr>
      <th>1</th>
      <td>M</td>
      <td>79.33</td>
      <td>Central</td>
      <td>78.33</td>
      <td>Others</td>
      <td>Science</td>
      <td>77.48</td>
      <td>Sci&amp;Tech</td>
      <td>Yes</td>
      <td>86.5</td>
      <td>Mkt&amp;Fin</td>
      <td>66.28</td>
      <td>Placed</td>
    </tr>
    <tr>
      <th>2</th>
      <td>M</td>
      <td>65.00</td>
      <td>Central</td>
      <td>68.00</td>
      <td>Central</td>
      <td>Arts</td>
      <td>64.00</td>
      <td>Comm&amp;Mgmt</td>
      <td>No</td>
      <td>75.0</td>
      <td>Mkt&amp;Fin</td>
      <td>57.80</td>
      <td>Placed</td>
    </tr>
    <tr>
      <th>3</th>
      <td>M</td>
      <td>56.00</td>
      <td>Central</td>
      <td>52.00</td>
      <td>Central</td>
      <td>Science</td>
      <td>52.00</td>
      <td>Sci&amp;Tech</td>
      <td>No</td>
      <td>66.0</td>
      <td>Mkt&amp;HR</td>
      <td>59.43</td>
      <td>Not Placed</td>
    </tr>
    <tr>
      <th>4</th>
      <td>M</td>
      <td>85.80</td>
      <td>Central</td>
      <td>73.60</td>
      <td>Central</td>
      <td>Commerce</td>
      <td>73.30</td>
      <td>Comm&amp;Mgmt</td>
      <td>No</td>
      <td>96.8</td>
      <td>Mkt&amp;Fin</td>
      <td>55.50</td>
      <td>Placed</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>210</th>
      <td>M</td>
      <td>80.60</td>
      <td>Others</td>
      <td>82.00</td>
      <td>Others</td>
      <td>Commerce</td>
      <td>77.60</td>
      <td>Comm&amp;Mgmt</td>
      <td>No</td>
      <td>91.0</td>
      <td>Mkt&amp;Fin</td>
      <td>74.49</td>
      <td>Placed</td>
    </tr>
    <tr>
      <th>211</th>
      <td>M</td>
      <td>58.00</td>
      <td>Others</td>
      <td>60.00</td>
      <td>Others</td>
      <td>Science</td>
      <td>72.00</td>
      <td>Sci&amp;Tech</td>
      <td>No</td>
      <td>74.0</td>
      <td>Mkt&amp;Fin</td>
      <td>53.62</td>
      <td>Placed</td>
    </tr>
    <tr>
      <th>212</th>
      <td>M</td>
      <td>67.00</td>
      <td>Others</td>
      <td>67.00</td>
      <td>Others</td>
      <td>Commerce</td>
      <td>73.00</td>
      <td>Comm&amp;Mgmt</td>
      <td>Yes</td>
      <td>59.0</td>
      <td>Mkt&amp;Fin</td>
      <td>69.72</td>
      <td>Placed</td>
    </tr>
    <tr>
      <th>213</th>
      <td>F</td>
      <td>74.00</td>
      <td>Others</td>
      <td>66.00</td>
      <td>Others</td>
      <td>Commerce</td>
      <td>58.00</td>
      <td>Comm&amp;Mgmt</td>
      <td>No</td>
      <td>70.0</td>
      <td>Mkt&amp;HR</td>
      <td>60.23</td>
      <td>Placed</td>
    </tr>
    <tr>
      <th>214</th>
      <td>M</td>
      <td>62.00</td>
      <td>Central</td>
      <td>58.00</td>
      <td>Others</td>
      <td>Science</td>
      <td>53.00</td>
      <td>Comm&amp;Mgmt</td>
      <td>No</td>
      <td>89.0</td>
      <td>Mkt&amp;HR</td>
      <td>60.22</td>
      <td>Not Placed</td>
    </tr>
  </tbody>
</table>
<p>215 rows × 13 columns</p>
</div>




```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 215 entries, 0 to 214
    Data columns (total 13 columns):
     #   Column               Non-Null Count  Dtype  
    ---  ------               --------------  -----  
     0   gender               215 non-null    object 
     1   ssc_percentage       215 non-null    float64
     2   ssc_board            215 non-null    object 
     3   hsc_percentage       215 non-null    float64
     4   hsc_board            215 non-null    object 
     5   hsc_subject          215 non-null    object 
     6   degree_percentage    215 non-null    float64
     7   undergrad_degree     215 non-null    object 
     8   work_experience      215 non-null    object 
     9   emp_test_percentage  215 non-null    float64
     10  specialisation       215 non-null    object 
     11  mba_percent          215 non-null    float64
     12  status               215 non-null    object 
    dtypes: float64(5), object(8)
    memory usage: 22.0+ KB
    

# Exploratory Data  Analysis


```python
data.hist(bins=25, figsize=(15,15))
plt.show()
```


    
![png](output_8_0.png)
    



```python
features = data[["gender","ssc_percentage","ssc_board","hsc_percentage","hsc_board","hsc_subject","degree_percentage",
                 "undergrad_degree","work_experience","emp_test_percentage","specialisation","mba_percent","status"]].columns
plt.figure(figsize=(15,8*4))
gs = gridspec.GridSpec(8, 2)
for i, c in enumerate(data[features]):
    ax = plt.subplot(gs[i])
    sns.countplot(data = data, x = c,palette="Set3")
plt.show()
```


    
![png](output_9_0.png)
    


# Data Cleaning


```python
data.isna().any()
```




    gender                 False
    ssc_percentage         False
    ssc_board              False
    hsc_percentage         False
    hsc_board              False
    hsc_subject            False
    degree_percentage      False
    undergrad_degree       False
    work_experience        False
    emp_test_percentage    False
    specialisation         False
    mba_percent            False
    status                 False
    dtype: bool



## converting Categorical variable with Numerical values.


```python
data.gender = data.gender.replace({"M": 1, "F" : 0})
data.ssc_board = data.ssc_board.replace({"Others":1,"Central":0})
data.hsc_board = data.hsc_board.replace({"Others":1,"Central":0})
data.hsc_subject = data.hsc_subject.replace({"Commerce":2,"Science":1,"Arts":0})
data.undergrad_degree = data.undergrad_degree.replace({"Sci&Tech":2,"Comm&Mgmt":1,"Others":0})
data.work_experience = data.work_experience.replace({"Yes":1,"No":0})
data.specialisation = data.specialisation.replace({"Mkt&HR":1,"Mkt&Fin":0})
data.status = data.status.replace({"Placed":1,"Not Placed":0})
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gender</th>
      <th>ssc_percentage</th>
      <th>ssc_board</th>
      <th>hsc_percentage</th>
      <th>hsc_board</th>
      <th>hsc_subject</th>
      <th>degree_percentage</th>
      <th>undergrad_degree</th>
      <th>work_experience</th>
      <th>emp_test_percentage</th>
      <th>specialisation</th>
      <th>mba_percent</th>
      <th>status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>67.00</td>
      <td>1</td>
      <td>91.00</td>
      <td>1</td>
      <td>2</td>
      <td>58.00</td>
      <td>2</td>
      <td>0</td>
      <td>55.0</td>
      <td>1</td>
      <td>58.80</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>79.33</td>
      <td>0</td>
      <td>78.33</td>
      <td>1</td>
      <td>1</td>
      <td>77.48</td>
      <td>2</td>
      <td>1</td>
      <td>86.5</td>
      <td>0</td>
      <td>66.28</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>65.00</td>
      <td>0</td>
      <td>68.00</td>
      <td>0</td>
      <td>0</td>
      <td>64.00</td>
      <td>1</td>
      <td>0</td>
      <td>75.0</td>
      <td>0</td>
      <td>57.80</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>56.00</td>
      <td>0</td>
      <td>52.00</td>
      <td>0</td>
      <td>1</td>
      <td>52.00</td>
      <td>2</td>
      <td>0</td>
      <td>66.0</td>
      <td>1</td>
      <td>59.43</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>85.80</td>
      <td>0</td>
      <td>73.60</td>
      <td>0</td>
      <td>2</td>
      <td>73.30</td>
      <td>1</td>
      <td>0</td>
      <td>96.8</td>
      <td>0</td>
      <td>55.50</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



# Data Visualization


```python
feature = ['gender','undergrad_degree','work_experience','specialisation']
fig, ax = plt.subplots(2,2, figsize = (10,10))
axs=ax.ravel()
for i, feature in enumerate(feature):
    sns.countplot(x = feature, hue = 'status',ax=axs[i], data=data,palette="terrain")
```


    
![png](output_16_0.png)
    


# Visualization

##### Males are getting placed more compared to females.
##### Students having a degree of Comm&Mgt have a high count of getting placed.
##### Students having no work experience are more likely to be placed but overall students with work experience are also placed.
##### Males in Marketing and Finance are getting placed more compared to Males in Marketing and HR. However Females in Marketing and HR are getting placed more compared to Marketing and Finance


```python
plt.pie(x = data.groupby(['status']).status.count(),
        labels = ["Not Placed", "Placed"], autopct='%1.2f%%',
        colors=['#ff9999','#66b3ff'])
```




    ([<matplotlib.patches.Wedge at 0x205609459d0>,
      <matplotlib.patches.Wedge at 0x20560929100>],
     [Text(0.6136308257718237, 0.9129387765138416, 'Not Placed'),
      Text(-0.6136309112473185, -0.912938719061573, 'Placed')],
     [Text(0.3347077231482674, 0.49796660537118626, '31.16%'),
      Text(-0.3347077697712646, -0.4979665740335852, '68.84%')])




    
![png](output_18_1.png)
    



```python
plt.figure(figsize=(12, 7))
plt.title("Relation Between Gender vs mba_percent")

sns.boxplot(x='gender',y='mba_percent',data=data,palette='winter')
```




    <AxesSubplot:title={'center':'Relation Between Gender vs mba_percent'}, xlabel='gender', ylabel='mba_percent'>




    
![png](output_19_1.png)
    



```python
plt.figure(figsize=(12, 7))
plt.title("Relation Between Status vs mba_percent ")

sns.boxplot(x='status',y='mba_percent',data=data,palette='winter')
```




    <AxesSubplot:title={'center':'Relation Between Status vs mba_percent '}, xlabel='status', ylabel='mba_percent'>




    
![png](output_20_1.png)
    


# Splitting the Data into Training and Testing Data


```python
X=data.drop(['status'], axis=1)
Y=data['status']
```


```python
X
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gender</th>
      <th>ssc_percentage</th>
      <th>ssc_board</th>
      <th>hsc_percentage</th>
      <th>hsc_board</th>
      <th>hsc_subject</th>
      <th>degree_percentage</th>
      <th>undergrad_degree</th>
      <th>work_experience</th>
      <th>emp_test_percentage</th>
      <th>specialisation</th>
      <th>mba_percent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>67.00</td>
      <td>1</td>
      <td>91.00</td>
      <td>1</td>
      <td>2</td>
      <td>58.00</td>
      <td>2</td>
      <td>0</td>
      <td>55.0</td>
      <td>1</td>
      <td>58.80</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>79.33</td>
      <td>0</td>
      <td>78.33</td>
      <td>1</td>
      <td>1</td>
      <td>77.48</td>
      <td>2</td>
      <td>1</td>
      <td>86.5</td>
      <td>0</td>
      <td>66.28</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>65.00</td>
      <td>0</td>
      <td>68.00</td>
      <td>0</td>
      <td>0</td>
      <td>64.00</td>
      <td>1</td>
      <td>0</td>
      <td>75.0</td>
      <td>0</td>
      <td>57.80</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>56.00</td>
      <td>0</td>
      <td>52.00</td>
      <td>0</td>
      <td>1</td>
      <td>52.00</td>
      <td>2</td>
      <td>0</td>
      <td>66.0</td>
      <td>1</td>
      <td>59.43</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>85.80</td>
      <td>0</td>
      <td>73.60</td>
      <td>0</td>
      <td>2</td>
      <td>73.30</td>
      <td>1</td>
      <td>0</td>
      <td>96.8</td>
      <td>0</td>
      <td>55.50</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>210</th>
      <td>1</td>
      <td>80.60</td>
      <td>1</td>
      <td>82.00</td>
      <td>1</td>
      <td>2</td>
      <td>77.60</td>
      <td>1</td>
      <td>0</td>
      <td>91.0</td>
      <td>0</td>
      <td>74.49</td>
    </tr>
    <tr>
      <th>211</th>
      <td>1</td>
      <td>58.00</td>
      <td>1</td>
      <td>60.00</td>
      <td>1</td>
      <td>1</td>
      <td>72.00</td>
      <td>2</td>
      <td>0</td>
      <td>74.0</td>
      <td>0</td>
      <td>53.62</td>
    </tr>
    <tr>
      <th>212</th>
      <td>1</td>
      <td>67.00</td>
      <td>1</td>
      <td>67.00</td>
      <td>1</td>
      <td>2</td>
      <td>73.00</td>
      <td>1</td>
      <td>1</td>
      <td>59.0</td>
      <td>0</td>
      <td>69.72</td>
    </tr>
    <tr>
      <th>213</th>
      <td>0</td>
      <td>74.00</td>
      <td>1</td>
      <td>66.00</td>
      <td>1</td>
      <td>2</td>
      <td>58.00</td>
      <td>1</td>
      <td>0</td>
      <td>70.0</td>
      <td>1</td>
      <td>60.23</td>
    </tr>
    <tr>
      <th>214</th>
      <td>1</td>
      <td>62.00</td>
      <td>0</td>
      <td>58.00</td>
      <td>1</td>
      <td>1</td>
      <td>53.00</td>
      <td>1</td>
      <td>0</td>
      <td>89.0</td>
      <td>1</td>
      <td>60.22</td>
    </tr>
  </tbody>
</table>
<p>215 rows × 12 columns</p>
</div>




```python
X_train, X_test, Y_train, Y_test = \
train_test_split(X, Y, test_size=0.3, random_state=42)
print("Number transactions X_train dataset: ", X_train.shape)
print("Number transactions Y_train dataset: ", Y_train.shape)
print("Number transactions X_test dataset: ", X_test.shape)
print("Number transactions Y_test dataset: ", Y_test.shape)
```

    Number transactions X_train dataset:  (150, 12)
    Number transactions Y_train dataset:  (150,)
    Number transactions X_test dataset:  (65, 12)
    Number transactions Y_test dataset:  (65,)
    

# Training Models

### 1. Decision Tree Classifier


```python
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, fbeta_score, roc_curve, auc
import matplotlib.pyplot as plt

# Create the Decision Tree Classifier
dtc = DecisionTreeClassifier(random_state=0)

# Fit the model
dtc.fit(X_train, Y_train)

# Make predictions
pred_dtc = dtc.predict(X_test)

# Calculate and print the metrics
dtc_accuracy = round(accuracy_score(Y_test, pred_dtc), 4) * 100
precision = round(precision_score(Y_test, pred_dtc), 2)
recall = round(recall_score(Y_test, pred_dtc), 2)
f1 = round(f1_score(Y_test, pred_dtc), 2)
f2 = round(fbeta_score(Y_test, pred_dtc, beta=2.0), 2)

print('Decision Tree Classifier- ')
print('accuracy  : ', dtc_accuracy)
print('Precision : ',precision)
print('Recall    : ', recall)
print('F1 Score  : ',f1)
print('F2 Score  : ',f2)

# Plot the ROC curve
fpr, tpr, thresholds = roc_curve(Y_test, pred_dtc)
roc_auc = auc(fpr, tpr)

plt.plot(fpr, tpr, lw=2, alpha=0.3, label='ROC (AUC = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], 'r--')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.title('Receiver Operating Characteristic')
plt.legend(loc='lower right')
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.show()
```

    Decision Tree Classifier- 
    accuracy  :  78.46
    Precision :  0.84
    Recall    :  0.84
    F1 Score  :  0.84
    F2 Score  :  0.84
    


    
![png](output_27_1.png)
    


### 2. Simple Linear Regression 


```python
regressor = LinearRegression()
regressor.fit(X_train, Y_train)
y_pred = regressor.predict(X_test)
print(y_pred)
```

    [0.84769054 0.75849259 0.89014713 0.31679713 0.86246081 0.13110753
     0.22018992 0.90102113 0.9517168  1.18920064 0.6214307  0.91050252
     0.30521517 0.76886997 1.10706869 0.46396157 1.20309677 0.46712171
     0.33026817 1.08640583 1.06190443 1.24232054 0.46173905 0.11715061
     0.84451675 1.07986474 0.37924221 0.77820851 0.77767799 0.7700559
     0.86951636 0.68325111 0.51589962 0.81581332 0.85665951 0.92275424
     0.42699859 0.55959632 1.02217028 0.90705358 1.1687743  0.77635859
     0.91466699 0.28236151 0.90714215 0.96917331 0.79230198 0.93236137
     0.64506185 1.21140322 0.98942311 0.78608742 1.00615468 0.47951279
     0.15371972 0.76076399 0.39182479 0.87927206 0.3847342  1.27370809
     0.6548543  0.72141295 0.22201443 0.45035389 0.01897726]
    


```python
# extract the independent variable (degree_percentage) and the dependent variable (status)
X = data['degree_percentage'].values.reshape(-1,1)
Y = data['status'].values.reshape(-1,1)

# create a linear regression object
model = LinearRegression()

# fit the model to the data
model.fit(X, Y)

# make a prediction for a new value of X (degree_percentage)
new_X = np.array([[27.94]])
y_pred = model.predict(new_X)
status_pred = round(y_pred[0][0])
# print the predicted status for someone with 67.94 degree percentage
print(status_pred)
```

    0
    


```python
lin_reg = LinearRegression()
lin_reg.fit(X_train,Y_train)
Y_predict = lin_reg.predict(X_test)
score = lin_reg.score(X_test, Y_test)
linaccuracy = round(score*100,2)
print('accuracy_score percent :', linaccuracy)
msr = np.mean((Y_predict-Y_test)**2)
print("Mean Squared error on Test set : ",msr)
```

    accuracy_score percent : 44.69
    Mean Squared error on Test set :  0.12095301813663555
    

### 3. Polynomial Regression 


```python
from sklearn.preprocessing import PolynomialFeatures
# extract the independent variable (degree_percentage) and the dependent variable (status)
X = data['work_experience'].values.reshape(-1,1)
Y = data['status'].values.reshape(-1,1)

# create a polynomial features object to transform X into polynomial features
poly_features = PolynomialFeatures(degree=2, include_bias=False)
X_poly = poly_features.fit_transform(X)

# create a linear regression object
poly_reg = LinearRegression()

# fit the model to the data
poly_reg.fit(X_poly, Y)

# make a prediction for a new value of X (work experience)
new_X = np.array([[10]])
new_X_poly = poly_features.transform(new_X)
status_pred = round(poly_reg.predict(new_X_poly)[0][0])

# print the predicted status for someone with 67.94 degree percentage
print(status_pred)
```

    15
    

# Model Selection and Performance


```python
m =ensemble.AdaBoostClassifier(n_estimators= 80)
pred =m.fit(X_train, Y_train).predict(X_test)
imp = m.feature_importances_

for i,v in enumerate(imp):
    print("Feature ",i," Score: ",v)
plt.bar([x for x in range(len(imp))],imp)
plt.show()
```

    Feature  0  Score:  0.0
    Feature  1  Score:  0.125
    Feature  2  Score:  0.0
    Feature  3  Score:  0.2375
    Feature  4  Score:  0.0
    Feature  5  Score:  0.0
    Feature  6  Score:  0.225
    Feature  7  Score:  0.0
    Feature  8  Score:  0.075
    Feature  9  Score:  0.125
    Feature  10  Score:  0.0125
    Feature  11  Score:  0.2
    


    
![png](output_35_1.png)
    



```python
m =ensemble.GradientBoostingClassifier(n_estimators=70, random_state = 123)
pred =m.fit(X_train, Y_train).predict(X_test)
imp = m.feature_importances_

for i,v in enumerate(imp):
    print("Feature ",i," Score: ",v)
plt.bar([x for x in range(len(imp))],imp)
plt.show()
```

    Feature  0  Score:  0.0007830619373312137
    Feature  1  Score:  0.5406982267502916
    Feature  2  Score:  0.00016804072283447858
    Feature  3  Score:  0.13059728172733953
    Feature  4  Score:  0.0008506864763334548
    Feature  5  Score:  4.71268653097443e-05
    Feature  6  Score:  0.12484548608897293
    Feature  7  Score:  0.00039964819687643655
    Feature  8  Score:  0.031590989917977305
    Feature  9  Score:  0.035656095498104196
    Feature  10  Score:  0.02862918193127047
    Feature  11  Score:  0.10573417388735863
    


    
![png](output_36_1.png)
    


# Final Report

##### During the exploratory data analysis (EDA), it was observed that a higher number of male students were placed in comparison to female students. Additionally, students who had pursued a degree in commerce and management had a higher likelihood of being placed. Work experience was found to be a contributing factor towards placement, although students without work experience were also placed. Marketing and human resources (HR) students had a higher likelihood of being placed compared to students studying marketing and finance.Despite female students performing well in their MBA courses, the salaries offered to male students were higher, and a greater number of male students were placed in comparison to female students. Based on the 12 features analyzed, it can be inferred that a student's academic performance from their 10th grade to MBA plays a significant role in their placement. Additionally, work experience can enhance a student's chances of being placed.


```python

```
